# TBomb
This is a SMS Bomber for Termux an Terminal Emulator for Android..

This Script is Only For Educational Purposes or To Prank.
 Do not Use This To Harm Others.
 I Am Not Responsible For The Misuse Of The Script.

The Script Requires A working Net Connection To Work..
No Balance will be deducted for using this script to send SMS...

 Make Sure To Update it for New Versions...

 That's All !!!

 This Bomber Was Created By SpeedX

To USE the script type the following commands in termux...

apt update

apt upgrade

apt install git

git clone https://github.com/navisaharan/SmsBomb.git

cd SmsBomb

chmod +x SmsBomb.sh

./SmsBomb.sh

Now the Script Will Execute..


For Any Queries Join Me On WhatsApp!!!
          Group Link: http://bit.do/thespeedx
  <a href="http://bit.do/thespeedx">Join My Group</a>

           Mail: ggspeedx29@gmail.com

           YouTube Channel: https://www.youtube.com/c/GyanaTech
  <a href="https://www.youtube.com/c/GyanaTech">Check My Channel</a>
